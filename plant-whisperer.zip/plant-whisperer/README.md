# Plant whisperer 

A Pen created on CodePen.

Original URL: [https://codepen.io/pvpzbxho-the-typescripter/pen/WbvyeZw](https://codepen.io/pvpzbxho-the-typescripter/pen/WbvyeZw).

